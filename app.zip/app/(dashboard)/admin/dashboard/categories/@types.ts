interface ICategory {
    id?: string;
    name: string;
    type: "RECEITA" | "DESPESA";
}